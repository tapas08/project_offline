<!--<div class="col-md-10" style="padding-top:15px;">-->
<div class="col-md-3">

					<div class="sidebar-collapse">
							<a href="productsale.php"><p><input type="button" value="F4 - Sale" class="btn btn-primary"/></p></a>
							<a href="productpur.php"><p><input type="button"  value="F5 - Purchase"  class="btn btn-primary"/></p></a>
							<a href="productsaleret.php"><p><input type="button"  value="F6 - Sale Ret"  class="btn btn-primary"/></p></a>
							<a href="productpurchaseret.php"><p><input type="button"  value="F7 - Pur Ret" 	class="btn btn-primary"/></p></a>
							<a href="productsale.php"><p><input type="button"  value="F8 - Ledger" 	class="btn btn-primary"/></p></a>
							<a href="productsale.php"><p><input type="button"  value="F9 - Stokist"	 class="btn btn-primary"/></p></a>
							<a href="productsummery.php"><p><input type="button"  value="F11 - Summery"  class="btn btn-primary"/></p></a>
							<p><button type="submit"  onclick="exportExcel();"  class="btn btn-primary">
							<i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button></p>

							<a href=""><p><input type="button"  value="ESC - Exit"  	class="btn btn-primary"/></p></a><br>
							
							
					</div>
							
</div>
<!--</div>-->