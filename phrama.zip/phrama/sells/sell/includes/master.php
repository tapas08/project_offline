
<?php require_once('core/init.php'); ?>
<!--<html>
<head>
<title>Matoshree Medicose</title>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
<link href="css/style2.css" type="text/css" rel="stylesheet">
</head>
<body >-->

 <script type="text/javascript">
	function getData(state){
			var drug = $('#product_name').val();
		
			console.log("getdata!!!");
			//console.log(id);
			//alert(id);
			$.ajax({
				type: 'post',
				url: 'functions/product_function.php',
				//dataType: 'json',
				data: {
					drug: drug,
					from: $('#from').val(),
					to  : $('#to').val(),
					access: state == "return" ? 'insertData1' : 'insertData'
				},
				success: function(data){
					console.log("success"+data);
					$('#tablebody').html(data);
					/*$("#content").html(data);
					getdata();
					$('#Sr.No.').val(data.Sr.No);
					$('#date').val(data.date);
					$('#invoiceNumber').val(data.invoiceNumber);
					$('#batchNo').val(data.batchNo);
					$('#expiryDate').val(data.expiryDate);
					$('#MRP').val(data.MRP);
					$('#productQuantity').val(data.productQuantity);
					$('#purchaseAmount').val(data.purchaseAmount);
					$('#Supplier').val(data.Supplier);*/
					
				},
				error: function(data){
					console.log(data);
				}
			});
			console.log("getdataend");
		}
	</script>
	
<div class="container-fluid">
	<div class="col-md-10 col-md-offset-1 text_style back1" >
		<div class="alert alert-info"><center>MATOSHREE MEDICOSE U/O TS LIFECARE<br>
		 MASTERS</center></div>
		<div class="col-md-12 middle_contain ">
		<form method="post" action= "productpur.php" enctype="multipart/form-data" >
		
		<div class="form-group col-md-8">
				<span class="col-md-4"><label for="productName" class="control-label">Product Name :</label></span>
				
				<span class="col-md-6"><input type="text" class="form-control" id="product_name" name="product_name" placeholder="Product Name" list="ProductList" oninput="getList4('product_name','ProductList',false,true);" required ></span>
				<datalist id="ProductList"></datalist>
			
			</div>
					
					
			<!--<table>
				<tr>
					<td class="text_style1">PRODUCT NAME : &nbsp; &nbsp; </td>
					<span class="col-lg-4"><td class="text_style1"><input type="text" style="width:350px;" class="form-control" name="product_name" id="product_name" list="ProductList" oninput ="getList4('product_name','ProductList',false,true);" required ></span>
					    <datalist id="ProductList"></datalist></td>
					
					<td class="text_style1">&nbsp&nbsp &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; NON &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; STOCK : </td>
				</tr>
			</table>
			<!--<div class="col-md-12" style="padding-top:15px;">
				<!--<div class="col-md-3 border_left">
							<p><input type="button"  value="F4 - Sale"      class="btn btn-primary"/></p>
							<p><input type="button"  value="F5 - Purchase"  class="btn btn-primary"/></p>
							<p><input type="button"  value="F6 - Sale Ret"  class="btn btn-primary"/></p>
							<p><input type="button"  value="F7 - Pur Rate" 	class="btn btn-primary"/></p>
							<p><input type="button"  value="F8 - Ledger" 	class="btn btn-primary"/></p>
							<p><input type="button"  value="F9 - Stokist"	 class="btn btn-primary"/></p><br>
							<p><input type="button"  value="F11 - Summery"  class="btn btn-primary"/></p><br>
							<p><input type="button"  value="ESC - Exit"  	class="btn btn-primary"/></p><br>
							
				</div>-->
					<!--<div class="col-md-9">-->
					<!--<table>
						<tr>
							<td class="text_style1" style="padding-top:10px;">FROM DATE :</td>
							<td class="text_style1" style="padding-top:15px;">
							<input type="date" style="width:170px;" class="form-control" name="from" id="from"/></td>
							<td class="text_style1" style="padding-top:15px;"> TO DATE:</td>
							<td class="text_style1" style="padding-top:15px;">
							<input type="date" style="width:170px;" class="form-control" name="to" id="to" /></td>
						</tr>
					</table>-->
				<!--</div>-->
						<div class="form-group col-md-6">
							<span class="col-md-4"><label for="sdate" class="control-label">From date:</label></span>
							<span class="col-md-8">
								<input type="date" id="from" class="form-control" name="from" value="2015-04-01" required>
							</span>
						</div>
						
						<div class="form-group col-md-6">
							<span class="col-md-4"><label for="edate" class="control-label">To date:</label></span>
							<span class="col-md-8">
								<input type="date" id="to" class="form-control" name="to" value="<?php echo date('Y-m-d') ?>" required>
							</span>
						</div>
			</form>
			</div>
			     
			<!--</div>-->
			
			
	
	</div>
	</div>
	<!--<div style="padding-top:100px;">
<nav>
	<ul class="pagination">
		<li>
			<a href="#" aria-label="Previous">
				<span aria-hidden="true">&laquo;</span>
			</a>
		</li>
		<li><a href="#">1</a></li>
		<li><a href="#">2</a></li>
		<li><a href="#">3</a></li>
		<li><a href="#">4</a></li>
		<li><a href="#">5</a></li>
		<li>
			<a href="#" aria-label="Next">
			<span aria-hidden="true">&laquo;</span>
			</a>
		</li>
		</ul>
</nav>
</div>-->
	
	<!--</body>
	</html>-->