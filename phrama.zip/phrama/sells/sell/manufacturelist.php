<?php

require_once('core/init.php');

$db = DB::getInstance();



if(!isset($_GET['page'])){ 
$page =1 ; //?
} else { 
$page = $_GET['page']; 
}

$max_results = 15; //?

$from = (($page * $max_results) - $max_results);
$limit = "$from, $max_results";
$company_list = $db->query("SELECT * FROM company_name LIMIT $limit");//?


$tots = DB::getInstance()->query("SELECT count(*) as Num FROM company_name");
	foreach ( $tots->results() as $tot => $num){
		$total_results = $num['Num'];
		}
$total_pages = ceil($total_results / $max_results);

			



?>
<html>
<head>
<title>Manufacturer List</title>
<link rel="stylesheet" href="css/bootstrap.min.css">

	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/jquery.table2excel.js"></script>
	
</head>
<body>

<div class="container">
	<div class="col-md-12 text-center page-header">

			<h2>MATOSHREE MEDICOSE U/O TS LIFECARE Pvt. Ltd.</h2>
			<h2>MANUFACTURER ITEM LIST</h2>
			
	</div>
	<div style="padding-left:90%;">
	<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
	</div>			
	
		<table class="table table-bordered table-hover table2excel">
			<tr>
			<td>Sr. No.</td>
			<td>Company Name</td>
			<td>Short Name</td>
		
			</tr>
			
		<tbody>
<?php 

	
	$sr = 1; foreach ( $company_list->results() as $data => $companyName){

?>
			
				<tr>
				<td><?php echo $sr ?></td>
				<td><?php echo $companyName['name'] ?></td>
				<td><?php echo $companyName['abbreviation'] ?></td>
				</tr>
				
<?php
$sr++; }
?>
</tbody>
</table>
<div class="col-md-10"  style="padding-left:45%;">
<ul class="pagination pagination-lg">
<?php						
			if($page > 1){ 
						$prev = ($page - 1); 
						//	echo "Page &n<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"><<Previous</a> "; 
						echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$prev\" class=page>&lt;&lt;Previous</a></li>";
						} 
											
			for($i = 1; $i <= $total_pages; $i++){ 
			if(($page) == $i){ 
					echo "<li><span class=\"display\">$i</span></li>"; 

					} else { 
				
					echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$i\" class=page>$i</a> </li>"; 
													} 
					} 
				 
										
								
			
					if($page < $total_pages){ 
										$next = ($page + 1); 
										echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$next\" class=page>Next&gt;&gt;</a></li>";
										} 		
		 
		 ?></ul><br>
		 </div>


</div>
</body>
<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>

</html>