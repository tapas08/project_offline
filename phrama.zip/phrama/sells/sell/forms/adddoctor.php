
<form method="post" id="addForm" action="DoctorMaster.php" class="col-md-12">
	<div class="form-group col-md-4">
		<label for="name" class="label-control">Name</label>
		<input type="text" id="doctor_name" class="form-control" name="doctor_name" placeholder="Doctor Name" >
	
	</div>
	<div class="form-group col-md-8">
		<label for="city" class="label-control">City</label>
		<select name="city" id="city" class="form-control" >
							<option value="-1" >select</option>
							<option  >Nagpur</option>
							<option  >Amravti</option>
							<option  >Washim</option>
							<option  >Pune</option>
							<option  >Akola</option>
							<option  >Wardha</option>
							<option  >Mumbai</option>
						</select>
		
	</div>
	
	<div class="form-group col-md-4">
		<label for="address" class="label-control">Address</label>
		<textarea name="address" id="address" class="form-control " rows=2></textarea>
	</div>
	
	<div class="form-group col-md-8">
		<label for="debit_limit" class="label-control">Qualification</label>
		<input type="text" id="qualification" class="form-control" name="qualification" placeholder="qualification" pattern ="[A-Za-z]*" >
	</div>
	<div class=" col-md-12">
		<br><br>
	</div>
	
	<div class=" col-md-3">
		<label for="phone" class="label-control">Phone number</label>
		<input type="text" name="phone" id="phone" class="form-control2">
	</div>
	
	<div class="col-md-3">
		<label for="reg_no" class="label-control">Register number</label>
		<input type="text" id="reg_no" class="form-control2" name="reg_no" placeholder="Reg no" required  pattern="[0-9]+">
	</div>
	<div class=" col-md-6">
		<label for="doctor" class="label-control">Doctor </label>
		<input type="text" id="HeadName" class="form-control2 " name="doctor_no" placeholder="doctor no" required pattern="[0-9]+">
	</div>
	<div class=" col-md-12">
	
	</br></br>
	</div>
	
	<div class="col-md-8">
						
						<input type="reset"  name="clear" id="clear" class="btn btn-primary" value="Cancel">
						<!--<a href="deletedoctor.php"><input type="button" id="pendingDM" name="pendingDM" class="btn btn-primary" onclick="checkPendingDM();" value="F8 Delete"></a>
						<input type="button" form="modify" id="modify_doc" name="modify_doc"  class="btn btn-primary" value="Modify">-->
						<input type="submit" form="addForm" id="saveInvoice" name="submit" class="btn btn-primary" value="Save">
						<a href="sells.php"><input type="submit" data-dismiss="modal" name="Exit" class="btn btn-primary" value="Exit"></a>
				
				</div>
				
	</form>
	<script src="script/jquery-min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	
	<script>
$('#modify_doc').click(function(){
		$('#modal-newDoctor').modal('hide');
		$('#modal-modifyDoc').modal();
	});	
</script>

		

