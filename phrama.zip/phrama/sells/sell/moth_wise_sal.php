<?php 
//set_time_limit(999);
require_once('core/init.php');
$tmon;
	$message = [];
	$detail = [];
	$details = [];
	$data =[];
	$data1 =[];
	$tot_sal= 0;
	$tot_salr =0;$tot_pur =0;
	$sum =0;
	$session_id = session_id();
	$db = DB::getInstance();
	
						
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>SELL</title>
	<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	
	<script src="script/jquery-min.js"></script>
	<script src="script/jquery.table2excel.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>

	
</head>

<body>
		
	<section class="container">
<div >
				<center><h3 style="color:grey;">MATOSHREE MEDICOSE U/O TS Lifecare Pvt Ltd.</h3>
				<h3 >Kanade Bal Rugnalaya,Hingoli Highway Road,Washim</h3>
				<h3 style="border-bottom:2px grey solid;color:grey;">MONTH WISE SALE PURCHASE SUMMARY</h3>
			
				<input type="data" id="datePicker" name="datePicker" style="visibility:hidden;">
			<center>
</div>			
<div class="container-fluid" >
<div style="padding-left:90%;">
<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
</div>			
	
					<table class="table table-bordered table2excel">
					<thead style="background-color:#F4F4F4">
						
						<td>Month</td>
						<td>Sale</td>
						<td>Sale Ret</td>
						<td>Gen.Sale </td>
						<td>Total Sale</td>
						<td>Purchase</td>
						
						
					</thead>
					<tbody>
					
					<?php 
					
					$sum=0;
					$months = array (1=>'January',2=>'February',3=>'March',4=>'April',
					5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'october',
					11=>'November',12=>'December');
					
					$s = "16-01-01";
				
					$c = date('Y-m-d');
					//echo $c;
				$n =0;
					while($s!=$c)
					{
					$newmonth = date("m",strtotime($s));
					
					$detail = $db->query("SELECT  sum(purchaseAmount)
					FROM purchasebills where month(date)='".$newmonth."' 
					group by month(date)");
					if($detail->count() >0){
					foreach($detail->results() as $data => $its){
					$tot_pur = $its['sum(purchaseAmount)'];	
					}
					}
						
					 $details = DB::getInstance()->query("SELECT sum(total_amt)
					 FROM patients where month(date)='".$newmonth."'  group by month(date)");
				
					if($details->count() >0){
					foreach($details->results() as $data => $itms){
					 $tot_sal = $itms['sum(total_amt)']; 	
					}
					}
					
					$ret = DB::getInstance()->query("SELECT sum(salreturn_amt) FROM
					salereturn where month(return_date)='".$newmonth."'  group by month(return_date)");
					if($detail->count() >0){
					foreach($ret->results() as $data => $retn){
					$tot_salr = $retn['sum(salreturn_amt)'];	
					}
					}
					//if( $details->count() > 0){
					//foreach($details->results() as $data => $itms){
	if($newmonth!= $n){

					?>
					
					
						<tr>
						<td  style="color:gray">
						<?php
												echo $tmon = $months[(int)$newmonth ];
						$n = date("m",strtotime($tmon)); //}?>
					
						</td>
						<?php
						//foreach($details->results() as $data => $itms){?>
							<td><?php echo  $tot_sal ;//$itms['sum(total_amt)'];
							?></td>
							<?php //} 
							?>
						
						<?php 
						
						?>
							<td ><?php echo $tot_salr;//$retn['sum(salreturn_amt)'];
							
							?></td>
							<?php //}
							?>
							
							<td><?php echo ".00"?></td>
							<td><?php echo "0" ;//$sum = $tot_sal + $tot_salr;?></td>

							<?php
									
							?>
							<td><?php echo $tot_pur; // $its['sum(purchaseAmount)'];?></td>
					<?php //}	 ?>		
							
							
						</tr>
						
						<?php 
					}
						$s = strtotime( "+1 day" , strtotime($s) ) ;
						$s = date ( 'Y-m-d' , $s );
					
						}
						?>
						
					</tbody>
				</table>
</div>
</section>
</body>
<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>

</html>
							