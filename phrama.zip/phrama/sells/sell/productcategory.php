<?php
require_once('core/init.php');

$db = DB::getInstance();

//$product = $db->query("SELECT * FROM product_type");
if(!isset($_GET['page'])){ 
$page =1 ; //?
} else { 
$page = $_GET['page']; 
}

$max_results = 15; //?

$from = (($page * $max_results) - $max_results);
$limit = "$from, $max_results";
$res = $db->query("SELECT * FROM product_type LIMIT $limit");

$tots = DB::getInstance()->query("SELECT count(*) as Num FROM product_type");
	foreach ( $tots->results() as $tot => $num){
		$total_results = $num['Num'];
		}
$total_pages = ceil($total_results / $max_results);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Manufacture wise Item List</title>
	
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
<script src="script/jquery.table2excel.js"></script>
	
</head>
<body>

<div class="container">
	<div class="col-md-12 text-center page-header">
		<h3>MATOSHREE MEDICOSE U/O TS LIFECARE Pvt. Ltd.</h3>
		<h3>ITEM LIST</h3>
	</div>
	<div style="padding-left:90%;">
	<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
	</div>			

	<table class="table table-bordered table-striped table-hover table2excel">
		<thead class="text-center">
			
			<td>Sr. No</td>
			<td>CODE</td>
			<td>CATEGORY NAME</td>
			
			
		</thead>
		<tbody>
<?php 



	
	$x = 1; foreach ( $res->results() as $data => $item){

?>
			<tr class="text-center">
				<td><?php echo $x ?></td>
				
				<td><?php echo $item['abbreviation'] ?></td>
				<td><?php echo $item['type'] ?></td>
				
		
				
			</tr>


<?php
$x++; }
?>
                		</tbody>
	</table>
</div>
<div class="col-md-10"  style="padding-left:45%;">
<ul class="pagination pagination-lg">
<?php						
			if($page > 1){ 
						$prev = ($page - 1); 
						//	echo "Page &n<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"><<Previous</a> "; 
						echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$prev\" class=page>&lt;&lt;Previous</a></li>";
						} 
											
			for($i = 1; $i <= $total_pages; $i++){ 
			if(($page) == $i){ 
					echo "<li><span class=\"display\">$i</span></li>"; 

					} else { 
				
					echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$i\" class=page>$i</a> </li>"; 
													} 
					} 
				 
										
								
			
					if($page < $total_pages){ 
										$next = ($page + 1); 
										echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$next\" class=page>Next&gt;&gt;</a></li>";
										} 		
		 
		 ?></ul><br>
		 </div>
</body>
<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>

</html>