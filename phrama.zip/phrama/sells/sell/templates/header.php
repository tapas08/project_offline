<nav class="navbar navbar-default">
	<div class="navbar-brand">Medical Shop</div>
	<div class="navbar-header">
		<ul class="nav navbar-nav top-menu">
			<li><a href="/project_offline/index.php">Home</a></li>
			<li><a href="/project_offline/purchase.php" target="_new">Update Inventory</a></li>
			<li><a href="/project_offline/purchaseInvoice.php" target="_window">Purchase Invoice</a></li>
			<!--<li><a href="#" data-toggle="modal" data-target=".modal-newCustSupp">New Customer</a></li>-->
			<!--<li><a href="#" data-toggle="modal" data-target=".modal-newCustSupp">New Supplier</a></li>
			<li><a href="#" data-toggle="modal" data-target=".modal-newCompany">New Company</a></li>
			-->
			<li><a href="#" data-toggle="modal" data-target=".modal-newDoctor">New Doctor</a></li>
			<li><a href="/project_offline/sells/sell/sells.php" target="_window">Sell</a></li>
			<li><a href="/project_offline/sells/sell/search_bill.php" >Sell Return</a></li>
			<li><a href="/project_offline/purchaseReturn.php" target="_window">Purchase Return</a></li>
		</ul>
	</div>
</nav>