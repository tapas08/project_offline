<nav class="navbar navbar-default">
	<div class="navbar-brand">Cancel</div>
	<div class="navbar-header">
		<ul class="nav navbar-nav">
			
			<li><a href="event.php">Event</a></li>
			<li><a href="search_bill.php">Search</a></li>
			<!--<li><a href="#" data-toggle="modal" data-target=".modal-newCustSupp">ToDays</a></li>-->
			<li><a href="bill1.php" data-toggle="modal" data-target=".modal-newCustSupp">RePrn</a></li>
			<li ><a href="sells.php">Exit</a></li>
		</ul>
	</div>
</nav>