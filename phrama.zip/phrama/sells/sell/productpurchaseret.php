
<?php require_once('core/init.php'); ?>
<html>
<head>
<title>Matoshree Medicose</title>
    <link href="css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="css/style2.css" type="text/css" rel="stylesheet">
	<script src="script/jquery-min.js"></script>
    <script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/pur.js"></script>
	<script src="script/bootstrap.min.js"></script>
</head>
<body >

<nav class="navbar navbar-default">
	
	<div class="navbar-header">
		<ul class="nav navbar-nav">
			<li><a href="supplier_list.php" class="navbar-right">Supplier List</a></li>
			<li><a href="customerList.php">Customer List</a></li>
			<li><a href="manufacturelist.php">Manufacturer List</a></li>
			<li><a href="categorywiseitem.php">Categorywise Item List</a></li>
			<li><a href="productcategory.php">Product Category</a></li>
			<li><a href="item_list.php">Item List</a></li>
			<li><a href="mf_itemlist.php">Mf_wise item List</a></li>
			<li><a href="newitem_date.php">New item between date</a></li>
		</ul>
	</div>
</nav>

		<?php
			require_once("includes/master.php");

		?>
		
		<div style="float:left;padding-left:120px;padding-top:30px;">
		<?php
			require_once("includes/leftpanel.php");

		?>
		</div>
		
			    <div style="padding-left:60px;" class="container-fluid col-md-8">
									<table class="table table-bordered table-condensed">
												<thead>
													<td >Sr.No.</td>
													<td >BTYPE</td>
													<td >INV_DATE</td>
													<td >INVNO</td>
													<td >BATCH</td>
													<td >EXP</td>
													<td >AMOUNT</td>
													<td >SUPPLIER</td>
												</thead>
											
											<tbody id="tablebody">
											
											</tbody>
									</table>
				</div>
<body>
</html>