<?php 
//set_time_limit(999);
require_once('core/init.php');
	$session_id = session_id();
	$db = DB::getInstance();
$total_qty =0;
$tempdoc = 0;

						
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>SELL</title>
	<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	
	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/jquery.table2excel.js"></script>
	

</head>

<body>
		
	<section class="container">
<div >
				<center><h3 style="color:grey;">MATOSHREE MEDICOSE U/O TS Lifecare Pvt Ltd.</h3>
				<h3 >Kanade Bal Rugnalaya,Hingoli Highway Road,Washim</h3>
				<h3 style="border-bottom:2px grey solid;color:grey;">Item WISE SALE :01/04/2015 To <?php echo date('d-m-y'); ?> </h3>
			
				<input type="data" id="datePicker" name="datePicker" style="visibility:hidden;">
			<center>
</div>	
<div style="padding-left:90%;">
<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
</div>			
		
<div class="container-fluid" >
<?php
										
 
					$details = DB::getInstance()->query("SELECT * FROM items ORDER BY productName asc");
					if ($details->count() > 0){
					foreach($details->results() as $data => $items){
						
					$productname = $items['productName'];
					$pksize = $items['packSize'];
					
					echo "<h4>PRODUCT :&nbsp;&nbsp;$productname&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PACK :&nbsp;&nbsp;$pksize</h4>";
					
					
					?>
	
					<table class="table table-bordered table2excel">
					<thead style="background-color:#F4F4F4">
						<td>MFG</td>
						<td>Batch</td>
						<td>Expiry</td>
						<td>Pack Size</td>

						<td>QTY</td>
						<td>MRP </td>
						<td>Tax </td>
						<td>AMT </td>
						<td>Bill No </td>
						<td>Date </td>
	
						
						
						
					</thead>
					<tbody>
					<?php 
					$ret = DB::getInstance()->query("SELECT * FROM patients");
					
					foreach($ret->results() as $data => $itm)//foreach($details->results() as $data => $itms)
					{
					$bill = json_decode($itm['bill'],true);
						foreach($bill as $content => $dm)
						{
						
							if($productname == $content)
							{
							
					?>
					
					
						
						<tr>
					
							
							
							<td><?php echo $dm['manufacturer'];?></td>
							
							<td ><?php echo $dm['batchNo'];?></td>
							<td ><?php echo  $dm['expiryDate'];?></td>
							<td><?php echo $dm['packSize'];?></td>
							<td><?php
							echo  $dm['quantity'];
							?></td>
							<?php $total_qty = $total_qty +  $dm['quantity'];?>
							<td><?php echo  $dm['MRP'];?></td>
							<td><?php echo  $dm['Tax'];?></td>
							<td><?php echo  $itm['total_amt'];?></td>
							<td><?php echo  $itm['bill_no'];?></td>
							<td><?php echo $itm['date'];?></td>
						
							
						</tr>
						
						
					<?php  }else{
					
					}
					}
					}
					?>
					<?php if($tempdoc != $total_qty){?>
					<tr>
					<td colspan="10" style="text-align:center;">
					<?php  echo "<h4>Quantity  total : &nbsp;&nbsp;&nbsp;$total_qty </h4>"  ;
						$tempdoc = $total_qty ;
						?>
						
					</td>
					</tr>
					
					<?php  }
					$total_qty =0;
					?>

					</tbody>
					
				</table>
				</br>
				
				<?php
				}				
					
					}else{
						echo "DATA NOT FOUND";
					}
				
					?>
     				
</div>
</section>
</body>
<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>

</html>
							