function getList5(id, list, drug, insertData){
	var value = document.getElementById(id).value;
	//alert(value);
	//id = (id.substr(7) == "MarketedBy") ? id.substr(7) : (id.substr(7) == "Manftr" ? 'company_name' : id);

	console.log(value);

	$.ajax({
		url: 'functions/summery_function.php',
		type: 'post',
		data: {
			searchTerm: value,
			table: 'sell_items',
			access:  (drug == true) ? 'getDrug' : 'getList5',
		},
		success: function(data){
			console.log("6789"+data);
			document.getElementById(list).innerHTML = data;
			//console.log(data);
			/*if (id == 'doctor_name'){
				if ( document.getElementById('productMarketedBy') !== null){
					document.getElementById('productMarketedBy').value = document.getElementById('company_name').value;
				}
				if ( document.getElementById('productManftr') !== null ){
					document.getElementById('productManftr').value = document.getElementById('company_name').value;
				}
			}*/

			if (insertData != null && insertData == true){
				console.log("hehe");
				getData("return");
			}
		}
	});
}


