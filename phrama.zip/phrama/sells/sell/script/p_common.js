function getList4(id, list, drug, insertData){
	var value = document.getElementById(id).value;
	//alert(value);
	//id = (id.substr(7) == "MarketedBy") ? id.substr(7) : (id.substr(7) == "Manftr" ? 'company_name' : id);

	console.log(value);

	$.ajax({
		url: 'functions/product_function.php',
		type: 'post',
		data: {
			searchTerm: value,
			table: 'purchasebills',
			//from: $('#from').val(),
			//to  : $('#to').val(),
			access:  (drug == true) ? 'getDrug' : 'getList4',
		},
		success: function(data){
			console.log("6789"+data);
			document.getElementById(list).innerHTML = data;
			//console.log(data);
			/*if (id == 'doctor_name'){
				if ( document.getElementById('productMarketedBy') !== null){
					document.getElementById('productMarketedBy').value = document.getElementById('company_name').value;
				}
				if ( document.getElementById('productManftr') !== null ){
					document.getElementById('productManftr').value = document.getElementById('company_name').value;
				}
			}*/

			if (insertData != null && insertData == true){
				console.log("hehe");
				getData("purchase");
			}
		}
	});
}


