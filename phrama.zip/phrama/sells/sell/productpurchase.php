<?php require_once('core/init.php'); ?>

<html>
<head>
<title>Matoshree Medicose</title>
	<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
	<link href="css/style2.css" type="text/css" rel="stylesheet">
	<script src="script/jquery-min.js"></script>
    <script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/p_common.js"></script>
	<script src="script/bootstrap.min.js"></script>
</head>
<body >

		<?php
			require_once("includes/master.php");

		?>
		<div style="float:left">
		<?php
			require_once("includes/leftpanel.php");

		?>
		</div>
		

				
			<div style="float:left;padding-left:20px;padding-top:40px;">	
				<table  class="table table-bordered" width="300px">
				<thead class="back">
				<td>INV_DATE</td>
				<td>PINVNO</td>
				<td>BATCH</td>
				<td>EXP</td>
				<td>MRP</td>
				<td>QTY</td>
				<td>SCHEME</td>
				<td>PURVALUE</td>
				<td>SUPPLIER</td>
				</thead>
				
				
				<tbody>
				
				</tbody>
				</table>
		</div>
			
<body>
</html>