<?php require_once('core/init.php');?>
<html>
<head>
<title>Matoshree Medicose</title>
<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
<link href="css/style2.css" type="text/css" rel="stylesheet">
</head>
<body >

		<?php
			require_once("includes/master.php");

		?>
		<?php
			require_once("includes/leftpanel.php");

		?>
			<div style="padding-right:10px;">
											<table class="tr td"cellspacing="0px" style="border:1px solid #000000;">
												<tr>
													<td class="table_head">Sr.No.</td>
													<td class="table_head">BTYPE</td>
													<td class="table_head">INV_DATE</td>
													<td class="table_head">INVNO</td>
													<td class="table_head">BATCH</td>
													<td class="table_head">EXP</td>
													<td class="table_head">AMOUNT</td>
													<td class="table_head">SUPPLIER</td>
													
												</tr>
												
<?php 

$db = DB::getInstance();

$purchase = $db->query("SELECT * FROM purchasebills ");

	$x = 1; foreach ( $purchase->results() as $data => $item){

?>
												<tr>
													<td class="table_head1"><?php echo $x ?></td>
													<td class="table_head1"><?php echo $item['bType'] ?></td>
													<td class="table_head1"><?php echo $item['date'] ?></td>
													<td class="table_head1"><?php echo $item['invoiceNumber'] ?></td>
													<td class="table_head1"><?php echo $item['batchNo'] ?></td>
													<td class="table_head1"><?php echo $item['expiryDate'] ?></td>
													<td class="table_head1"><?php echo $item['purchaseAmount'] ?></td>
													<td class="table_head1"><?php echo $item['supplier'] ?></td>
												</tr>
<?php
$x++; }
?>
											</table>
</div>											
						
</body>
</html>