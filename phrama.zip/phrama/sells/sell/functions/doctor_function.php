<?php 

require_once('../core/init.php');
if (Input::exists()){
	$functionName = Input::get('access');

	switch ($functionName){
		case 'getDrug':
			getDrug();
			break;
		case 'insertData':
			insertData();
			break;
		case 'update':
			updateData();
			break;
		case 'delete':
			deleteDrug();
			break;
		case 'getList_2':
			getList_2(Input::get('table'));
			break;
	}
}

function getDrug(){
	$db = DB::getInstance();
	$searchTerm = Input::get('searchTerm');
	$searchTerm = "%$searchTerm%";

	$get = $db->query("SELECT * FROM doctor_details WHERE `doctor_name` LIKE ?", array($searchTerm));

	if (!$get->error()){
		//if($get->count() > 0){
			//insertData();
		//}
		foreach ($get->results() as $key => $value){
			echo "<option value='{$value['doctor_name']}'>{$value['doctor_name']}</option>";
		}
	}else{
		echo "Error!";
	}

}

function insertData(){
	$db = DB::getInstance();
	$drug = Input::get('drug');
	
	$details = $db->get("doctor_details", array('doctor_name', '=', $drug));

	if ($details){
		$data = [];
		$data['address'] = $details->first()['address'];
		$data['city'] = $details->first()['city'];
		$data['qualification'] = $details->first()['qualification'];
		$data['reg_no'] = $details->first()['reg_no'];
		$data['contact_no'] = $details->first()['contact_no'];
		$data['doctor_no'] = $details->first()['doctor_no'];
		
		
		echo json_encode($data);
	}else{
		echo "ERROR!";
	}
}

function updateData(){
	$db = DB::getInstance();
	if (Input::exists()){
		$update = $db->update('doctor_details', array('doctor_name', '=', Input::get('doctor_name')), array(
			'doctor_name'		=> Input::get('doctor_name'),
			'address'			=> Input::get('address'),
			'city'				=> Input::get('city'),
			'qualification'		=> Input::get('qualification'),
			'reg_no'			=> Input::get('reg_no'),
			'contact_no'		=> Input::get('contact_no'),
			'doctor_no'		    => Input::get('doctor_no')
			));
		
		if ($update){
			echo "Doctor entry updated!";
		}else{
			echo "Error! Something went wrong during process.";
		}

	}else{
		echo "No Input";
	}

}

function deleteDrug(){
	if (Input::exists()){
		$db = DB::getInstance();

		$delete = $db->query("DELETE FROM doctor_details WHERE `doctor_name` = ?", array(Input::get('productName')));
		if (!$delete->error()){
			echo "Doctor entry deleted!";
		}else{
			echo "Error! Something went wrong during process.";
		}
	}
}

function getList_2($table){
	if (Input::exists()){
		$db = DB::getInstance();

		$searchTerm = Input::get('searchTerm');
		$searchTerm = "%$searchTerm%";

		$get = $db->query("SELECT * FROM doctor_details WHERE `doctor_name` = ?", array($searchTerm));
		print_r($get);

		if (!$get->error() && $get->count() > 0){
			foreach ($get->results() as $key => $value) {
				echo "<option value='",$value['doctor_name'],"'>{$value['doctor_name']}  {$value['doctor_name']}</option>";
			}
		}
	}
}