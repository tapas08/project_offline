<?php 

require_once('../core/init.php');
if (Input::exists()){
	$functionName = Input::get('access');

	switch ($functionName){
		case 'getDrug':
			getDrug();
			break;
		case 'insertData':
			insertData();
			break;
		case 'update':
			updateData();
			break;
		case 'delete':
			deleteDrug();
			break;
		case 'getList_4':
			getList_4(Input::get('table'));
			break;
	}
}

function insertData(){
	
	$db = DB::getInstance();
	$drug = Input::get('drug');
	$x=1;
	$bill = array();
	
	echo $from = date("Y-m-d",strtotime(Input::get('from')));
	echo $to   = date("Y-m-d",strtotime(Input::get('to')));
	
	while(strtotime($from)<= strtotime( $to))
	{
	
	
		$detail = $db->query("SELECT * from patients Where date =?", array($from)  );
		
		if($detail->count()>0){
		foreach($detail->results() as $row => $data)
		{
	
			$bill = json_decode($data['bill'],true);
			
			foreach($bill as $content => $dm)
			{
				
			//$details = $db->query("SELECT * from patients WHERE  AND date =?",array($from));
				
			if($content == $drug)
			{
	
				//if($details && $details->count()>0){
				//foreach($details->results() as $row => $item)
				//{
	
				echo "<tr>";
				echo"<td>" .$x. "</td>";
				echo"<td>" .$data['date'] ."</td>";
				echo"<td>" .$data['bill_no'] ."</td>";
				echo"<td>" .$dm['quantity'] ."</td>";
				echo"<td>" .$dm['batchNo'] ."</td>";
				echo"<td>" .$dm['expiryDate'] ."</td>";
				echo"<td>" .$data['total_amt'] ."</td>";
				echo"<td>" .$data['patient_name'] ."</td>";
				echo"</tr>";
				$x++;
				
			}
			else { echo "product not found";}
			}
		}
			}else{ echo "No Sale ";}
			$from = date("Y-m-d", strtotime('+1 day',strtotime($from)));
			}

	}
	
function getList_4($table){
	if (Input::exists()){
		$db = DB::getInstance();

		echo $searchTerm = Input::get('searchTerm');
		$searchTerm = "%{$searchTerm}%";
		
		$get = $db->query("SELECT * FROM items WHERE productName LIKE ?", array($searchTerm));
		print_r($get);

		if (!$get->error() && $get->count() > 0){
			foreach ($get->results() as $key => $value) {
				echo "<option value='",$value['productName'],"'>{$value['productName']}  {$value['productName']}</option>";
			}
		}else{
			echo "error";
			print_r($get->results());
		}
	}
}