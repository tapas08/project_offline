<?php 

require_once('../core/init.php');
if (Input::exists()){
	$functionName = Input::get('access');

	switch ($functionName){
		case 'getDrug':
			getDrug();
			break;
		case 'insertData':
			insertData();
			break;
		case 'insertData1':
			insertData1();
			break;
		case 'update':
			updateData();
			break;
		case 'delete':
			deleteDrug();
			break;
		case 'getList5':
			getList5(Input::get('table'));
			break;
	}
}

function insertData(){
	$db = DB::getInstance();
	$drug = Input::get('drug');
	$x=1;
	$details = $db->query("SELECT sel.productName,pat.date,pat.bill_no, sel.quantity,sel.batchNo,sel.expiryDate,sel.total_amt,pat.patient_name 
	FROM sell_items AS sel INNER JOIN patients AS pat ON pat.id=sel.patient_id WHERE sel.productName =?", array($drug));

	if($details){
	foreach($details->results() as $row => $item)
	{
	echo "<tr>";
	echo"<td>" .$x. "</td>";
	echo"<td>" .$item['date'] ."</td>";
	echo"<td>" .$item['bill_no'] ."</td>";
	echo"<td>" .$item['quantity'] ."</td>";
	echo"<td>" .$item['batchNo'] ."</td>";
	echo"<td>" .$item['expiryDate'] ."</td>";
	echo"<td>" .$item['total_amt'] ."</td>";
	echo"<td>" .$item['patient_name'] ."</td>";
	echo"</tr>";
	$x++;
	}
	
	}
	else{ echo "ERROR!";}
}	

function getList5($table){
	if (Input::exists()){
		$db = DB::getInstance();

		$searchTerm = Input::get('searchTerm');
		$searchTerm = "%{$searchTerm}%";

		$get = $db->query("SELECT sel.productName,pat.date,pat.bill_no, sel.quantity,sel.batchNo,sel.expiryDate,sel.total_amt,pat.patient_name 
		FROM sell_items AS sel INNER JOIN patients AS pat ON pat.id=sel.patient_id WHERE sel.productName LIKE ?", array($searchTerm));
		//print_r($get);

		if (!$get->error() && $get->count() > 0){
			print_r($get->results());
			foreach ($get->results() as $key => $value) {
				echo "<option value='",$value['productName'],"'>{$value['productName']}  {$value['productName']}</option>";
			}
		}else{
			echo "error";
			print_r($get->results());
		}
	}
}

