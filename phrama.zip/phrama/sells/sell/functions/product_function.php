<?php 

require_once('../core/init.php');
if (Input::exists()){
	$functionName = Input::get('access');

	switch ($functionName){
		case 'getDrug':
			getDrug();
			break;
		case 'insertData':
			insertData();
			break;
		case 'insertData1':
			insertData1();
			break;
		case 'update':
			updateData();
			break;
		case 'delete':
			deleteDrug();
			break;
		case 'insData':
			insData();
			break;
		case 'getList4':
			getList4(Input::get('table'));
			break;
	}
}

function insertData(){
	$db = DB::getInstance();
	$drug = Input::get('drug');
	$x=1;
	
	echo $from = date("Y-m-d",strtotime(Input::get('from')));
	echo $to   = date("Y-m-d",strtotime(Input::get('to')));
	
	while(strtotime($from)<= strtotime( $to))
	{
		
	$details = $db->query("SELECT * from purchasebills WHERE productName=? AND date =?",array($drug,$from));
	if($details && $details->count()>0){
	foreach($details->results() as $row => $item)
	{
	echo "<tr>";
	echo"<td>" .$x. "</td>";
	echo"<td>" .$item['date']."</td>";
	echo"<td>" .$item['invoiceNumber'] ."</td>";
	echo"<td>" .$item['batchNo'] ."</td>";
	echo"<td>" .$item['expiryDate'] ."</td>";
	echo"<td>" .$item['MRP'] ."</td>";
	echo"<td>" .$item['productQuantity'] ."</td>";
	echo"<td>" .$item['purchaseAmount'] ."</td>";
	echo"<td>" .$item['supplier'] ."</td>";
	echo"</tr>";
	$x++;
	}
	}
	else{ echo "ERROR!";
	}
	$from = date("Y-m-d", strtotime('+1 day',strtotime($from)));

	}
}	

function insertData1(){
	$db = DB::getInstance();
	$drug = Input::get('drug');
	$x=1;
	
	echo $from = date("Y-m-d",strtotime(Input::get('from')));
	echo $to   = date("Y-m-d",strtotime(Input::get('to')));
	
	while(strtotime($from)<= strtotime( $to))
	{
	
	$details = $db->query("SELECT * from purchasebills WHERE productName=? AND date =?",array($drug,$from));
	if($details && $details->count()>0){
	foreach($details->results() as $row => $item)
	{
	echo "<tr>";
	echo"<td >" .$x. "</td>";
	echo"<td >" .$item['bType']."</td>";
	echo"<td >" .$item['date'] ."</td>";
	echo"<td >" .$item['invoiceNumber'] ."</td>";
	echo"<td >" .$item['batchNo'] ."</td>";
	echo"<td >" .$item['expiryDate'] ."</td>";
	echo"<td >" .$item['purchaseAmount'] ."</td>";
	echo"<td >" .$item['supplier'] ."</td>";
	echo"</tr>";
	$x++;
	}
	}
	else{ echo "ERROR!";}
	$from = date("Y-m-d", strtotime('+1 day',strtotime($from)));
}
}
	
	/*if ($details){
		$data = [];
		$data['SrNo'] = $details->first()['SrNo'];
		$data['date'] = $details->first()['date'];
		$data['invoiceNumber'] = $details->first()['invoiceNumber'];
		$data['batchNo'] = $details->first()['batchNo'];
		$data['expiryDate'] = $details->first()['expiryDate'];
		$data['MRP'] = $details->first()['MRP'];
		$data['productQuantity'] = $details->first()['productQuantity'];
		$data['purchaseAmount'] = $details->first()['purchaseAmount'];
		$data['supplier'] = $details->first()['supplier'];
		
		echo json_encode($data);
	}else{
		echo "ERROR!";
	}
}*/

function getList4($table){
	if (Input::exists()){
		$db = DB::getInstance();
		
		echo $searchTerm = Input::get('searchTerm');
		$searchTerm = "%{$searchTerm}%";
		
		$get = $db->query("SELECT * FROM purchasebills WHERE productName LIKE ? " , array($searchTerm)); 
		//print_r($get);

		if (!$get->error() && $get->count() > 0){
			foreach ($get->results() as $key => $value) {
				echo "<option value='",$value['productName'],"'>{$value['productName']}  {$value['productName']}</option>";
			}
		}else{
			echo "error";
			print_r($get->results());
		}
		
	}
}


