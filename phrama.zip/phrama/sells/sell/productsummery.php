
<?php require_once('core/init.php');?>

<html>
<head>
<title>Matoshree Medicose</title>
		<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
	<link href="css/style2.css" type="text/css" rel="stylesheet">
	<script src="script/jquery-min.js"></script>
    <script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/summery.js"></script>
	<script src="script/bootstrap.min.js"></script>
</head>
<body >

<nav class="navbar navbar-default">
	
	<div class="navbar-header">
		<ul class="nav navbar-nav">
			<li><a href="supplier_list.php" class="navbar-right">Supplier List</a></li>
			<li><a href="customerList.php">Customer List</a></li>
			<li><a href="manufacturelist.php">Manufacturer List</a></li>
			<li><a href="categorywiseitem.php">Categorywise Item List</a></li>
			<li><a href="productcategory.php">Product Category</a></li>
			<li><a href="item_list.php">Item List</a></li>
			<li><a href="mf_itemlist.php">Mf_wise item List</a></li>
			<li><a href="newitem_date.php">New item between date</a></li>
		</ul>
	</div>
</nav>

       <script>
	function getData(star){
			var drug = $('#product_name').val();
		
			console.log("getdata!!!");
			//console.log(id);
			//alert(id);
			$.ajax({
				type: 'post',
				url: 'functions/summery_function.php',
				//dataType: 'json',
				data: {
					drug: drug,
					access: star == "return" ? 'insertData1' : 'insertData'
				},
				success: function(data){
					console.log("success"+data);
					$('#tablebody1').html(data);
					/*$("#content").html(data);
					getdata();
					$('#Sr.No.').val(data.Sr.No);
					$('#date').val(data.date);
					$('#invoiceNumber').val(data.invoiceNumber);
					$('#batchNo').val(data.batchNo);
					$('#expiryDate').val(data.expiryDate);
					$('#MRP').val(data.MRP);
					$('#productQuantity').val(data.productQuantity);
					$('#purchaseAmount').val(data.purchaseAmount);
					$('#Supplier').val(data.Supplier);*/
					
				},
				error: function(data){
					console.log(data);
				}
			});
			console.log("getdataend");
		}
	</script>



<div class="container-fluid">
	<div class="col-md-10 col-md-offset-1 text_style back1" >
		<div class=" alert alert-info" id="Message"><center>MATOSHREE MEDICOSE U/O TS LIFECARE<br>
		 MASTERS</center></div>
		
			<form method="post" action="#" enctype="multipart/form-data" >
		
		    <div class="form-group col-md-10" >
				<span class="col-md-3"><label for="productName" class="control-label">Product Name :</label></span>
				
				<span class="col-md-6"><input type="text" class="form-control" id="product_name" name="product_name" list="ProductList" oninput="getList_4('product_name','ProductList',false,true);" required ></span>
				<datalist id="ProductList"></datalist>
			
			</div>
			
			<!--<div class="col-md-12" style="padding-top:15px;">
				<!--<div class="col-md-3 border_left">
							<p><input type="button"  value="F4 - Sale"      class="btn btn-primary"/></p>
							<p><input type="button"  value="F5 - Purchase"  class="btn btn-primary"/></p>
							<p><input type="button"  value="F6 - Sale Ret"  class="btn btn-primary"/></p>
							<p><input type="button"  value="F7 - Pur Rate" 	class="btn btn-primary"/></p>
							<p><input type="button"  value="F8 - Ledger" 	class="btn btn-primary"/></p>
							<p><input type="button"  value="F9 - Stokist"	 class="btn btn-primary"/></p><br>
							<p><input type="button"  value="F11 - Summery"  class="btn btn-primary"/></p><br>
							<p><input type="button"  value="ESC - Exit"  	class="btn btn-primary"/></p><br>
							
				</div>-->
					<!--<div class="col-md-9">-->
					<div class="form-group col-md-6">
							<span class="col-md-4"><label for="sdate" class="control-label">From date:</label></span>
							<span class="col-md-8">
								<input type="date" id="from" class="form-control" name="from" value="2015-04-01" required>
							</span>
						</div>
						
						<div class="form-group col-md-6">
							<span class="col-md-4"><label for="edate" class="control-label">To date:</label></span>
							<span class="col-md-8">
								<input type="date" id="to" class="form-control" name="to" value="<?php echo date('Y-m-d') ?>" required>
							</span>
						</div>
				<!--</div>-->


			</form>
			     
			<!--</div>-->
	</div>
	</div>
	</div>
		
		<div style="float:left;padding-left:120px;padding-top:30px;">
		<?php
			require_once("includes/leftpanel.php");

		?>
		</div>
			<div class="container-fluid col-md-8">
											<table class="table table-bordered table-hover" >
												<thead>
													<td >Sr.No.</td>
													<td >Op stock</td>
													<td >Purchase</td>
													<td >Sale</td>
													<td >Pur ret</td>
													<td >Sale ret</td>
													<td >Adj Qty</td>
													<td >CI stock</td>
												</thead>
												
												<tbody>
													
													
												</tbody>
									</table>
</div>											
</body>
</html>