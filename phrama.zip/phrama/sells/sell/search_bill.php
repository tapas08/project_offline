<?php
$data1 = array();
$prdt = array();
$count_bill;$pats;$bill;
$ad_ret;
$Bll;
require_once('core/init.php');
 
if(isset($_POST['save'])){
	
	if(isset($_POST['selector'])){
	
		$select[] = $_POST['selector'];
		foreach($select as $demo){
		
		$prdt = $demo;
		
		}
	}


if(isset($_POST['bill_no'])){
	
 
$getbill = DB::getInstance()->get("patients", array('bill_no', '=',$_POST['bill_no'] ));
 
}elseif(isset($_POST['bill_no1'])){

$getbill = DB::getInstance()->get("patients", array('bill_no', '=',$_POST['bill_no1'] ));	

}elseif(isset($_POST['patient_name'])){
	
$getbill = DB::getInstance()->get("patients", array('patient_name', '=',$_POST['patient_name'] ));	

}else{
	echo "No Bill";
}

	$i =1;
  if($getbill->count()> 0)
{
	foreach ($getbill->results() as $data => $bill1){
	$pats = $bill1["patient_name"];
	$Bll = $bill1["bill_no"];
	$bill = json_decode($bill1['bill'], true);
			
	foreach ($bill as $content => $dm){
	$count_bill = count($bill);
		/*if($prdt[$i-1] == $content){*/
			
		$data1["productName_$i"] =$content;
		$data1["quantity_$i"]= $dm["quantity"];
		$data1["productRate_$i"]= $dm["productRate"];
		$data1["MRP_$i"]= $dm["MRP"];
		$data1["batchNo_$i"]= $dm["batchNo"];
		$data1["packSize_$i"]= $dm["packSize"];
		$data1["expiryDate_$i"]= $dm["expiryDate"];
		$data1["manufacturer_$i"]= $dm["manufacturer"];
		$data1["purchaseSize_$i"]= $dm["purchaseSize"];
		$data1["Tax_$i"]= $dm["Tax"];
		$data1["shelf_$i"]= $dm["shelf"];
		$data1["cost_$i"]= $dm["cost"];
		$data1["return_$i"]= (isset($dm["return"])) ? $dm["return"] : 0;
		$data1["returnamt_$i"]= (isset($dm["returnamt"])) ? $dm["returnamt"] : 0;
		$i++;
		/*}*/
			}
		
	
	}	
	
}	

 $add =0 ;
	if(isset($data1))
	{
		if(isset($count_bill)){	
		for($i = 1; $i<=$count_bill; $i++){
			$add = $data1["return_$i"];
		//if(isset($_POST["return_$i"])){
			if(isset($_POST["return_$i"])){
			$add = $add + $_POST["return_$i"];
			}else{
				$add = $add + 0;
			}
			
					$bill_data[$data1["productName_$i"]] = array(
					'productName' 	    => $data1["productName_$i"],
					'quantity' 	        => $data1["quantity_$i"],
					'productRate' 	    => $data1["productRate_$i"],
					'MRP' 				=> $data1["MRP_$i"],
					'batchNo' 			=> $data1["batchNo_$i"],
					'packSize' 			=> $data1["packSize_$i"],
					'expiryDate' 		=> $data1["expiryDate_$i"],
					'manufacturer' 		=> $data1["manufacturer_$i"],
					'purchaseSize' 	    => $data1["purchaseSize_$i"],
					'Tax' 				=> $data1["Tax_$i"],
					'shelf' 			=> $data1["shelf_$i"],
					'cost'              => $data1["cost_$i"],
					'return' 			=> (isset($add)) ?  $add : $_POST["return_$i"],
					'returnamt' 		=> (isset($_POST["returnamt_$i"])) ? $_POST["returnamt_$i"] : 0
			);
			$bill = json_encode($bill_data);
			
			
			/*update the return stock form patients details by the bill_no1*/
				$insert = DB::getInstance()->update('patients',array('bill_no', '=',$_POST['bill_no1'] ), array(
				'bill' => $bill
				));
			
			
	
	
			/*update the return stock form patients details by bill_no*/
				$insert = DB::getInstance()->update('patients',array('bill_no', '=',$_POST['bill_no'] ), array(
				'bill' => $bill
				));
				/*update the return stock form patients details by patient_name*/
				$insert = DB::getInstance()->update('patients',array('patient_name', '=',$_POST['patient_name'] ), array(
				'bill' => $bill
				));


			/*update the return stock form items*/
			if(isset($_POST["return_$i"])){
			$get = DB::getInstance()->query("select * from purchasebills where productName='".$data1["productName_$i"]."' ");
				foreach ($get->results() as $key => $value){
				$tab = ($value['tabQuantity'])+ $_POST["return_$i"];
				}
				$insert = DB::getInstance()->update('purchasebills',array('productName', '=',$data1["productName_$i"] ), array(
				'tabQuantity' => $tab,

				));
				
				
				
  }
			}
			/*Insert the salereturn data*/
			$date = date('Y-m-d');
			//echo $Bll;
			//echo  $_POST['salreturn_amt'];
			$insert =  DB::getInstance()->insert('salereturn', array(
				'return_date' => $date,
				'bill_no' => $Bll,
				'bill' => $bill,
				'salreturn_amt' => $_POST['salreturn_amt']
				));	
	
		}//
		
		}
	
			
		
	}
	
				
	
	




?>

<!DOCTYPE html>
<head>
	<title>Sell</title>
	
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<!-- <link rel="stylesheet" type="text/css" href="css/theme.css"> -->
	<link rel="stylesheet" type="text/css" href="css/main.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<!-- <link rel="stylesheet" type="text/css" href="css/style2.css"> -->
		
	<script>
			// $('document').ready(function(){
			// 	//alert('hi');
			// 	$('#resultdata').load('show_search_bill.php');
				
			// 	$('#searchby').keyup(function(){
			// 		var sdata=$("#searchby").val();
			// 		//alert(sdata);
			// 		$('#resultdata').load('show_search_bill.php?getsearchdata='+sdata);
			// 		//alert(datas);
			// 	});
				
			// });
	</script>
	<style>
		.form-control{
			width: 100%;
		}

		label{
			margin-left: 5px;
		}

		#bill_content_details{
			height: 400px;
			overflow: auto;
		}

	</style>
</head>
<body>
<form method="POST"  >

	
	<div class="row">
		<?php include('templates/eventheader.php'); ?>
	</div>

	<div class="conatainer col-md-12">

       		<div class="row">
				<div class="col-md-2">
					<h2 class="text-warning text-center" style="margin-top: 0px">Bill searching</h2>	
				</div>
				<div class="col-md-10">
					<h4 class="text-info" id="Message">SEARCHING A BILL FOR SALE RETURN / MODIFICATION</h4>
				</div>
			</div>
			
			<div class="container">		
				<div class="row col-md-12">
					<div class="col-md-6">
						<div class="form-group col-md-4">
							<span class="col-md-4"><label for="year" class="control-label">Year</label></span>
							<span class="col-md-8">
								<select name="year" id="year" class="form-control">
									<option>2015-16</option>
									<option>2014-15</option>
									<option>2013-14</option>
									<option>2012-13</option>
									<option>2011-12</option>
									<option>2010-11</option>
								</select>
							</span>
						</div>
						
						<div class="form-group col-md-4">
							<span class="col-md-4"><label for="billType" class="control-label">BillType</label></span>
							<div class="col-md-4">
								<select name="billType" id="billType" class="form-control">
									<option value="C">C</option>
									<option value="E">E</option>
									<option value="G">G</option>
								</select>
							</div>
						</div>
						
						<div class="form-group col-md-4">
							<span class="col-md-4"><label for="bill_no" class="control-label">By Bill no</label></span>
							<span class="col-md-8">
								<input type="text" id="bill_no" class="form-control" name="bill_no" placeholder="Bill number"  oninput="searchByBill();">
							</span>
						</div>
						
						<div class="form-group col-md-6">
							<span class="col-md-4"><label for="sdate" class="control-label">From date</label></span>
							<span class="col-md-8">
								<input type="date" id="sdate" class="form-control" name="sdate" value="2015-04-01" required>
							</span>
						</div>
						
						<div class="form-group col-md-6">
							<span class="col-md-4"><label for="edate" class="control-label">To date</label></span>
							<span class="col-md-8">
								<input type="date" id="edate" class="form-control" name="edate" value="<?php echo date('Y-m-d') ?>" required>
							</span>
						</div>

						<div class="form-group col-md-6">
							<span class="col-md-4"><label for="searchByName"><!--<i class="fa fa-plus-square"></i>-->By name</label></span>
							<span class="col-md-8">
								<input type="text" id="Name" class="form-control" name="patient_name" placeholder="name"  oninput="searchByName();" />
							</span>
						</div>
						</br>
						
						<div class="form-group col-md-6">
							<span class="col-md-4">
							
							<label for="searchByProduct">By product</label>
							</span>
							<span class="col-md-8">
							<input type="text" id="Product" class="form-control" name="Product" placeholder="product name" >
							</span>
						
						</div>

						<div class="form-group col-md-6">
							<input type="button" name="change"  value="Change" onclick="sbill();" class="btn btn-success">
							<input type="reset" name="reset" value="Cancel" class="btn btn-success">
							<input type="submit" name="submit"  value="Exit" class="btn btn-success">
							
	
						</div>
					</div>
					<div class="col-md-offset-1 col-md-5" style="padding-left:0px;height:300px; overflow:auto;">
						<input type="button" id="goto_prev" style="visibility:hidden;" value="prev">
						<input type="button" id="goto_next" style="visibility:hidden;" value="next">
						<table class="table table-bordered table-condensed" id="bill_list">
							<thead class="text-center">
								<td>#</td>
								<td>Bill No</td>
								<td>Date</td>
								<td>Amount</td>
								<td>Patient</td>
							</thead>
							<tbody id="bill_table"></tbody>
						</table>
					</div>
				</div>
			</div>
	
	
		
		<div class="container" id="bill_content_details">
		<!--<form  method="post"><!--action="sells.php"-->
			<table class="table table-bordered table-condensed">
				<thead class="bg">
						<td>Sr.no</td>
						<td>Bill No</td>
						<td>Product Name</td>
						<td>Batch No.</td>
						<td>Pack</td>
						<td>Qty</td>
						<td>MRP</td>
						<td>Return</td>
						<td>Return Quantity</td>
						<td>Return Amount</td>
				</thead>
				<tbody id="bill_details">
				</tbody>
				
			</table>
			<div class="form-group col-md-12">
			<div class="col-md-2">
			<input type="submit" name="save"  value="submit" class="btn btn-success">
			</div>
			
			<div class="col-md-10" style="padding-left:40%">
			<span class="col-md-6">
							<label  for="net" class="control-label" ><strong>Total Sale Return :</strong></label>
						</span>
						<span class="col-md-6">
							<input type='text' id='salereturn_amt'  name='salreturn_amt' class='form-control3' >
					</span>
						
			
			</div>
			</div>
			
			</form>
	</div>
	</div>
	<script src="script/jquery-min.js"></script>
		<script src="script/searchBills.js"></script>
			
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/navigate.js"></script>
</body>
</html>
	<script>
	function calculate(count){
			console.log("hello");
			console.log("count"+count);
			var itemcost = 0 ;
			var totalCost = 0 ;
			
			//All already return drugs amount 
			
			var ret1 = $('#returnamt1_'+count+'').val();

			var ret = $('#return_'+count+'').val();
			var retq = parseFloat($('#return_'+count+'').val()) + parseFloat($('#returnq_'+count+'').val());
			var quantity = $('#quantity_'+count+'').val();
			 console.log("retq-> "+retq);
			if((ret > quantity) || (retq > quantity))
			{
				alert("Return Amt is large then Sale quantity....!");
				$space = 0;
				
				$('#return_'+count+'').val($space);
				
			}
			
			
			if(ret > 0){
			itemcost = parseFloat(parseFloat($('#return_'+count+'').val()) / parseFloat($('#packSize_'+count+'').val()) * parseFloat($('#MRP_'+count+'').val()));
			console.log("rettot -> "+itemcost);
			$('#returnamt_'+count).val(itemcost.toFixed(2));
			} else{
			$('#returnamt_'+count).val(itemcost.toFixed(2));	
			}
			
			if(ret1 < 0){
					for (var i = 1; i <= count; i++){
				 totalCost += parseFloat($("#returnamt_"+i).val());
				console.log("total cost "+totalCost);
					}
					}else{
						for (var i = count; i <= count; i++){
						totalCost += parseFloat($("#returnamt_"+i).val());
						console.log("total cost "+totalCost);
						}
					}
					
			
			/*
			 if (count){
				counter = count;
			} */
		//	getTotal1(counter);
$('#salereturn_amt').val(totalCost);
		}


	</script>