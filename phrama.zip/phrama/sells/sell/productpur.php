 
<?php require_once('core/init.php'); ?>

<html>
<head>
<title>Matoshree Medicose</title>
	<link href="css/bootstrap.css" type="text/css" rel="stylesheet">
	<link href="css/style2.css" type="text/css" rel="stylesheet">
	<script src="script/jquery-min.js"></script>
    <script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/p_common.js"></script>
	<!--<script src="script/bootstrap.min.js" type="text/css" rel="stylesheet"></script>-->
</head>
<body >

<nav class="navbar navbar-default">
	
	<div class="navbar-header">
		<ul class="nav navbar-nav">
			<li><a href="supplier_list.php" class="navbar-right">Supplier List</a></li>
			<li><a href="customerList.php">Customer List</a></li>
			<li><a href="manufacturelist.php">Manufacturer List</a></li>
			<li><a href="categorywiseitem.php">Categorywise Item List</a></li>
			<li><a href="productcategory.php">Product Category</a></li>
			<li><a href="item_list.php">Item List</a></li>
			<li><a href="mf_itemlist.php">Mf_wise item List</a></li>
			<li><a href="newitem_date.php">New item between date</a></li>
		</ul>
	</div>
</nav>

		<?php
			require_once("includes/master.php");

		?>
		<div style="float:left;padding-left:120px;padding-top:30px;">
		<?php
			require_once("includes/leftpanel.php");

		?>
		</div>
		
		
          
<!--<div class="container-fluid">
	<div class="col-md-10 col-md-offset-1 text_style back1" >
		<center>MATOSHREE MEDICOSE U/O TS LIFECARE<br>
		 MASTERS</center>
		<div class="col-md-12 middle_contain ">
		<form method="post" action="" enctype="multipart/form-data"  >
-			<table>
				<tr>
					<td class="text_style1">PRODUCT NAME : &nbsp &nbsp</td>
					<td class="text_style1"><input type="text" style="width:350px;" class="form-control"/></td>
					<td class="text_style1">&nbsp&nbsp &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; NON &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; STOCK : </td>
				</tr>
			</table>
			<div class="col-md-12" style="padding-top:15px;">
				<div class="col-md-3 border_left">
							<p><input type="button"  value="F4 - Sale"      class="btn btn-primary"/></p>
							<p><input type="button"  value="F5 - Purchase"  class="btn btn-primary"/></p>
							<p><input type="button"  value="F6 - Sale Ret"  class="btn btn-primary"/></p>
							<p><input type="button"  value="F7 - Pur Rate" 	class="btn btn-primary"/></p>
							<p><input type="button"  value="F8 - Ledger" 	class="btn btn-primary"/></p>
							<p><input type="button"  value="F9 - Stokist"	 class="btn btn-primary"/></p><br>
							<p><input type="button"  value="F11 - Summery"  class="btn btn-primary"/></p><br>
							<p><input type="button"  value="ESC - Exit"  	class="btn btn-primary"/></p><br>
							
				</div>
				<div class="col-md-9">
					<table>
						<tr>
							<td class="text_style1" style="padding-bottom:10px;">FROM DATE :-</td>
							<td class="text_style1" style="padding-bottom:10px;">
							<input type="date" style="width:170px;" class="form-control" name="sdate" placeholder="yyyy/mm/dd"/></td>
							<td class="text_style1" style="padding-bottom:10px;"> TO :- </td>
							<td class="text_style1" style="padding-bottom:10px;">
							<input type="date" style="width:170px;" class="form-control" name="edate" placeholder="yyyy/mm/dd"/></td>
						</tr>
						<tr>
							<!--<td colspan="4" style="border-top:2px solid #696969;border-left:2px solid #696969">-->
							<div style="padding-left:60px;" class="container-fluid col-md-8">
											<table class="table table-bordered table-condensed" >
												<thead>
													<td >Sr.No.</td>
													<td >INV_DATE</td>
													<td >PINVNO</td>
													<td >BATCH</td>
													<td >EXP</td>
													<td >MRP</td>
													<td >QTY</td>
													<!--<td class="table_head">SCHEME</td>-->
													<td >PURVALUE</td>
													<td >SUPPLIER</td>
													
												</thead>
												<tbody id="tablebody"> 
											
												</tbody>
											</table>
</div>											
							<!--</td>

							</tr>
					</table>
				</div>
				
			</div>
		</div>
	</div>
	</form>
</div>-->

<!--pagination-->
<div style="padding-top:350px;">
<center><nav>
	<ul class="pagination">
		<li>
			<a href="#" aria-label="Previous">
				<span aria-hidden="true">&laquo;</span>
			</a>
		</li>
		<li><a href="#">1</a></li>
		<li><a href="#">2</a></li>
		<li><a href="#">3</a></li>
		<li><a href="#">4</a></li>
		<li><a href="#">5</a></li>
		<li>
			<a href="#" aria-label="Next">
			<span aria-hidden="true">&laquo;</span>
			</a>
		</li>
		</ul>
</nav>
		<!--<ul class="pager">
		  <li><a href="#">Previous</a></li>
		  <li><a href="#">Next</a></li>
		</ul>-->
</center>
</div>
</body>
</html>