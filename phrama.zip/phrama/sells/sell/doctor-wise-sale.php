<?php 
//set_time_limit(999);
require_once('core/init.php');
	$session_id = session_id();
	$db = DB::getInstance();
$sr;
						
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>SELL</title>
	<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	
	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/jquery.table2excel.js"></script>
	

</head>

<body>
		
	<section class="container">
<div >
				<center><h3 style="color:grey;">MATOSHREE MEDICOSE U/O TS Lifecare Pvt Ltd.</h3>
				<h3 >Kanade Bal Rugnalaya,Hingoli Highway Road,Washim</h3>
				<h3 style="border-bottom:2px grey solid;color:grey;">DOCTOR WISE SALE :01/04/2015 To <?php echo date('d-m-y'); ?> </h3>
			
				<input type="data" id="datePicker" name="datePicker" style="visibility:hidden;">
			<center>
</div>	
<div style="padding-left:90%;">
<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
</div>			
		
<div class="container-fluid" >
	
					<table class="table table-bordered">
					<thead style="background-color:#F4F4F4">
						
						<td>Sr No</td>
						<td>Bill NO</td>
						<td>Date</td>
						<td>Amount</td>
						<td>Patient</td>
						
						
						
						
					</thead>
					<tbody>
					
					<?php
					$tempdoc = 'xxxxxx';
					

					$details = DB::getInstance()->query("SELECT doctor_name FROM doctor_details ORDER BY doctor_name asc");
					if ($details->count() > 0){
					foreach($details->results() as $data => $items){
						
					$doctName = $items['doctor_name'];
					
					$ret = DB::getInstance()->query("SELECT * FROM
					patients WHERE doctor_name='".$doctName."' ");
					if ($ret->count() > 0){
						
					
					?>
					
					<? if($doctName != $tempdoc){ ?>
					<tr>
			
	
						<td colspan="5" style="color:gray">
						<?php echo "DR. $doctName";?>
						
						</td>
					</tr>	
					<?php
					$tempdoc = $doctName; } ?>
					<?php 
						
					$sr=1;
					foreach($ret->results() as $data => $itm)//foreach($details->results() as $data => $itms)
					{
						
										?>
						
						<tr>
					
							
							<td><?php echo $sr; ?></td>
							<td><?php echo $itm['bill_no'];?></td>
							
							<td ><?php echo $itm['date'];?></td>
							<td><?php echo  $itm['total_amt'];?></td>
							
							<td><?php echo $itm['patient_name'];?></td>
						
							
						</tr>
						
					<?php  $sr++;}
					
					}
					
									
					
					}else{
						echo "DATA NOT FOUND";
					}
				
					?>
     					
					</tbody>
				</table>
</div>
</section>
</body>
</html>
							