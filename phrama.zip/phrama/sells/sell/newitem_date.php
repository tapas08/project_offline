<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>New Item between dates</title>
	<link rel="stylesheet" href="css/bootstrap.css">
</head>
<body>

<div class="container">
	<div class="col-md-12 text-center page-header">
		<h3>MATOSHREE MEDICOSE U/O TS LIFECARE Pvt. Ltd.</h3>
		<h3>NEW ITEM CREATED FROM DATE 01/04/2015 TO <?php echo date('d/m/20y'); ?></h3>
	</div>
	
	

<div class="container-fluid">
	<table class="table table-bordered table-striped">
		<thead>
			<td>SR.NO.</td>
			<td>MFG</td>
			<td>PRODUCT</td>
			<td>PACK</td>
			<td>PUR. RATE</td>
			<td>MRP</td>
			<td>RACK</td>
			<td>PrSz</td>
			<td>CAT</td>
			<td>eDATE</td>
		</thead>
		<tbody>
<?php 

require_once('core/init.php');

$db = DB::getInstance();

//$supplier_list = $db->get('account', array('ac_type', '=', 'Supplier'));

//if ($supplier_list->count() > 0){
	//foreach ($supplier_list->result() as $supplier_details => $supplier):
	
	$supplier_list = $db->query("SELECT * FROM purchase");

	$x = 1; 
	foreach ( $supplier_list->results() as $data => $item){

	?>
			<tr>
			    <td><?php echo $x ?></td>
				<td><?php echo $item['manufacturer'] ?></td>
				<td><?php echo $item['productName'] ?></td>
				<td><?php echo $item['packSize'] ?></td>
				
				<td><?php echo $item['purchaseRate'] ?></td>
				<td><?php echo $item['MRP'] ?></td>
				<td><?php echo $item['shelf'] ?></td>
				<td><?php echo $item['quantity'] ?></td>
				<td><?php echo $item['productType'] ?></td>
				<td><?php echo $item['exDate'] ?></td>
			</tr>

<?php

$x++; }

?>
		</tbody>
	</table>
	</div>
</div>
</body>
</html>