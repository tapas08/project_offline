<?php 
//set_time_limit(999);
require_once('core/init.php');
	$session_id = session_id();
	$db = DB::getInstance();
$sr;
$total_grant =0;
						
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>SELL</title>
	<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	
	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/jquery.table2excel.js"></script>
	

</head>

<body>
		
	<section class="container">
<div >
				<center><h3 style="color:grey;">MATOSHREE MEDICOSE U/O TS Lifecare Pvt Ltd.</h3>
				<h3 >Kanade Bal Rugnalaya,Hingoli Highway Road,Washim</h3>
				<h3 style="border-bottom:2px grey solid;color:grey;">DOCTOR WISE SALE SUMMARY :01/04/2015 To <?php echo date('d-m-y'); ?></h3>
			
				<input type="data" id="datePicker" name="datePicker" style="visibility:hidden;">
			<center>
</div>	
<div style="padding-left:90%;">
<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
</div>			
		
<div class="container-fluid" >
	
					<table class="table ">
					<thead style="background-color:#F4F4F4">
						
						<td>Doctor Name</td>
					
						<td>Amount</td>
						
						
						
						
						
					</thead>
					<tbody>
					
					<?php
					$tempdoc = 'xxxxxx';
					

					$details = DB::getInstance()->query("SELECT doctor_name FROM doctor_details ORDER BY doctor_name asc");
					if ($details->count() > 0){
					foreach($details->results() as $data => $items){
						
					$doctName = $items['doctor_name'];
					
					$ret = DB::getInstance()->query("SELECT sum(total_amt),doctor_name FROM
					patients WHERE doctor_name='".$doctName."' group by doctor_name ");
					if ($ret->count() > 0){	
					$sr=1;
					foreach($ret->results() as $data => $itm)//foreach($details->results() as $data => $itms)
					{
						
										?>
						<tr>
						<td>
							<?php echo $itm['doctor_name'];?>
						</td>
						<td><?php echo $itm['sum(total_amt)'];?></td>
						<?php $total_grant = $total_grant +  $itm['sum(total_amt)'];?>
							
						</tr>
						
					<?php  }
					
					}
					}				
					
					}else{
						echo "DATA NOT FOUND";
					}
				
					?>
                     
					 <tr>
					 <td><?php  echo "GRANT  TOTAL :"?></td>
						<td ><?Php 
						echo " $total_grant" ; ?>
						</td>
					</tr>
						                
	  
						
					</tbody>
				</table>
</div>
</section>
</body>
<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>

</html>
							