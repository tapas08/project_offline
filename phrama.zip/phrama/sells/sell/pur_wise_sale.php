<?php 
//set_time_limit(999);
require_once('core/init.php');
$tmon;
	$message = [];
	$detail = [];
	$details = [];
	$data =[];
	$data1 =[];
	$sum=0;
	$session_id = session_id();
	$db = DB::getInstance();
	
						
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>SELL</title>
	<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	
	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
	<script src="script/jquery.table2excel.js"></script>
	
</head>

<body>
		
	<section class="container">
<div >
				<center><h3 style="color:grey;">MATOSHREE MEDICOSE U/O TS Lifecare Pvt Ltd.</h3>
				<h3 >Kanade Bal Rugnalaya,Hingoli Highway Road,Washim</h3>
				<h3 style="border-bottom:2px grey solid;color:grey;">PURCHASE  WISE SALE </h3>
			
				<input type="data" id="datePicker" name="datePicker" style="visibility:hidden;">
			<center>
</div>			
<div class="container-fluid" >
<div style="padding-left:90%;">
<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
</div>			
	
					<table class="table table-bordered table2excel">
					<thead style="background-color:#F4F4F4">
						
						<td>Bill No</td>
						<td>Date</td>
						<td>PURPRICE</td>
						<td>MRP </td>
						<td>MRP + TAX</td>
						
						
						
					</thead>
					<tbody>
					
					<?php 
					
					$sum=0;
					
					$s = "15-04-01";
				
					$c = date('Y-m-d');
					//echo $c;
				$n =0;
					while($s!=$c)
					{
					$newmonth = date("m",strtotime($s));
					$detail = $db->query("SELECT productName,purchaseRate
					 FROM purchasebills ");
					if ($detail->count() > 0){
						
					foreach($detail->results() as $data => $items)//foreach($details->results() as $data => $itms)
					{
					   $prod = $items['productName'];
					   
					$ret = DB::getInstance()->query("SELECT  *	
					FROM patients where date='".$s."' ");
					foreach($ret->results() as $data => $itm)//foreach($details->results() as $data => $itms)
					{
					$bill = json_decode($itm['bill'],true);
						foreach($bill as $content => $dm)
						{
						
							if($prod == $content)
							{
					
					
					?>
					
					<?php
						
					
					?>
					
						
						<tr>
						<td><?php echo $itm['bill_no'];?></td>	
						<td><?php echo $itm['date'];?></td>
						<td><?php echo $items['purchaseRate'];?></td>
						<td><?php echo $dm['MRP'];?></td>
						<td><?php echo $dm['MRP']+$dm['Tax'];?></td>
						</tr>
						
					<?php
							}
						}
					}
					} 
					}
					?>
                      
						<?php 
					
						$s = strtotime( "+1 day" , strtotime($s) ) ;
						$s = date ( 'Y-m-d' , $s );
					
						}
						?>
						
					</tbody>
				</table>
</div>
</section>
</body>
<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>

</html>
							