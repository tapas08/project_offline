<?php 
require_once('core/init.php');
	$message = [];
	$details = [];
	$data=[];
	$session_id = session_id();
	$db = DB::getInstance();
	
if(!isset($_GET['page'])){ 
$page =1 ; //?
} else { 
$page = $_GET['page']; 
}

$max_results = 15; //?

$from = (($page * $max_results) - $max_results);
$limit = "$from, $max_results";
$details = $db->query("SELECT * FROM patients LIMIT $limit");//?


$tots = DB::getInstance()->query("SELECT count(*) as Num FROM patients");
	foreach ( $tots->results() as $tot => $num){
		$total_results = $num['Num'];
		}
$total_pages = ceil($total_results / $max_results);

			

	
?>
<html>
<head>
	<meta charset="UTF-8">
	<title>SELL</title>
	<link rel="stylesheet" href="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/themes/smoothness/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/invoice.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<script src="script/jquery-min.js"></script>
	<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.11.3/jquery-ui.min.js"></script>
	<script src="script/jquery.mtz.monthpicker.js"></script>
<script src="script/jquery.table2excel.js"></script>
	

</head>

<body>
		
	<section class="container">
<div >
				<center><h3 style="color:grey;">MATOSHREE MEDICOSE U/O TS Lifecare Pvt Ltd.</h3>
				<h3 style="border-bottom:2px grey solid;color:grey;">Cash Balance Summary date :01/04/2015 To <?php echo date('d-m-y'); ?></h3>
			
				<input type="data" id="datePicker" name="datePicker" style="visibility:hidden;">
			<center>
</div>
<div style="padding-left:90%;">
<button type="submit"  onclick="exportExcel();"  class="btn btn-primary"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;<b>Excel</b></button>
</div>			
			
<div class="container-fluid" >
	
					<table class="table table-bordered table-hover table2excel">
					<thead>
						<td></td>
						<td>BillNo</td>
						<td>Date</td>
						<td>Patient </td>
						<td>CASH</td>
						<td>Amount</td>
						<td>RECEIVED</td>
						<td>BALANCE</td>
					</thead>
					<tbody>
					<?php foreach($details->results() as $data => $item){?>
						<tr>
							<td><?php echo $item['cash-or-credit'];?></td>
							<td><?php echo $item['bill_no'];?></td>
							<td><?php echo $item['date'];?></td>
							<td><?php echo $item['patient_name'];?></td>
							<td><?php echo $item['total_amt']; ?></td>
							<td><?php echo $item['total_amt'];?></td>
							<td><?php echo $item['paid_amt'];?></td>
						   <td><?php echo $item['bal_amt'];?></td>
						</tr>
						<?php } ?>
					</tbody>
				</table>
</div>
<div class="col-md-10"  style="padding-left:45%;">
<ul class="pagination pagination-lg">
<?php						
			if($page > 1){ 
						$prev = ($page - 1); 
						//	echo "Page &n<a href=\"".$_SERVER['PHP_SELF']."?page=$prev\"><<Previous</a> "; 
						echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$prev\" class=page>&lt;&lt;Previous</a></li>";
						} 
											
			for($i = 1; $i <= $total_pages; $i++){ 
			if(($page) == $i){ 
					echo "<li><span class=\"display\">$i</span></li>"; 

					} else { 
				
					echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$i\" class=page>$i</a> </li>"; 
													} 
					} 
				 
										
								
			
					if($page < $total_pages){ 
										$next = ($page + 1); 
										echo "<li><a href=\"".$_SERVER['PHP_SELF']."?page=$next\" class=page>Next&gt;&gt;</a></li>";
										} 		
		 
		 ?></ul><br>
		 </div>

</section>
</body>

		<script>
			function exportExcel(){
				$(".table2excel").table2excel({
					exclude: ".noExl",
					name: "Excel Document Name",
					filename: "myFileName",
					fileext: ".xls",
					exclude_img: true,
					exclude_links: true,
					exclude_inputs: true
				});
			}
		</script>


</html>