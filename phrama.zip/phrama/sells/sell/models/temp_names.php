<?php

class temp_names  extends DB
{
	var $table = "temp_names";
	
	
}

?>