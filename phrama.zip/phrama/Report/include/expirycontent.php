<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-ban-circle"></i>&nbsp; EXPIRY</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">EXPIRY LIST ALL ITEMS</a></li>
												<li><a href="#">EXPIRY LIST BETWEEN TWO DATE</a></li>
                                                <li><a href="#">EXPIRY LIST RACK/SHELF WISE</a></li>
												<li><a href="#">EXPIRY LIST SUPPLIER WISE</a></li>
												<li><a href="#">PENDING EXPIRY/PUR-RET SUMMARY</a></li>
												<li><a href="#">PENDING EXPIRY/PUR-RET DETAILS</a></li>
												<li><a href="#">ADJUSTED EXPIRY/PUR-RET SUMMARY</a></li>
												<li><a href="#">ADJUSTED EXPIRY/PUR-RET DETAILS</a></li>
                                                <li><a href="#">EXPIRY/PUR-RET/BREAKAGE REGISTER</a></li>
                                             </ul>
										</div>
                                        <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>