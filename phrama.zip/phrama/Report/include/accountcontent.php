<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-tasks"></i>&nbsp; ACCOUNTS</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">LEDGER(VERTICAL FORMAT)</a></li>
												<li><a href="#">LEDGER (HORIZONTAL FORMAT)</a></li>
                                                <li><a href="#">CASH BOOK</a></li>
                                                <li><a href="#">JOURNAL</a></li>
                                                <li><a href="#">TRADING ACCOUNT</a></li>
                                                <li><a href="#">INCOME-EXPENDITURE (P&L) </a></li>
                                                <li><a href="#">TRAIL BALANCE</a></li>
                                                <li><a href="#">SUNDRY CREDITORS</a></li>
                                                <li><a href="#">SUNDRY DEBTORS</a></li>
                                                <li><a href="#">BALANCE SHEET</a></li>
                                                <li><a href="#">LEDGER STATMENT</a></li>
                                                <li><a href="#">OPENING BALANCES</a></li>
                                                <li><a href="#">ALL LEDGER PRINTING</a></li>
                                                <li><a href="#">CASH FLOW STATEMENT</a></li>
                                             </ul>
										</div>
                                        <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>