<div id="block_bg" class="block">
                
	<div class="block-content collapse in">
		<div class="span12">
        	<div class="row">
				<div class="header"><i class="icon-book"></i>&nbsp; STOCK</div>
			</div>
            <div class="content span12">
				<div class=" span4 pre-scrollable">
					<ul class="nav nav-stacked">
						<li><a href="#">CLOSING STOCK</a></li>
						<li><a href="#">CLOSING STOCK-PUR RATE WISE</a></li>
                        <li><a href="#">CLOSING STOCK-NET-RATE WISE</a></li>
                        <li><a href="#">CLOSING STOCK-COMPANY WISE</a></li>
                        <li><a href="#">CLOSING STOCK-MRP WISE</a></li>
                        <li><a href="#">CLOSING STOCK-SUB CATEGORYWISE</a></li>
                        <li><a href="#">CLOSING STOCK-SHELF WISE</a></li>
                        <li><a href="#">CLOSING STOCK-CATEGORY WISE</a></li>
                        <li><a href="#">CLOSING STOCK-SUPPLIER WISE</a></li>
                        <li><a href="#">CLOSING STOCK-BANK</a></li>
                        <li><a href="#">CLOSING STOCK-BACKDATED</a></li>
                        <li><a href="#">STOCK AND SALE SUMMARY</a></li>
                        <li><a href="#">ITEM LEDGER</a></li>
                        <li><a href="#">ZERO STOCK ITEMS</a></li>
                     </ul>
				</div>
                <?php include('include/form.php'); ?>
		    </div>
	    </div>
    </div>
