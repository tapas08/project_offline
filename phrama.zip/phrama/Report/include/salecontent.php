<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-bar-chart"></i>&nbsp; SALES</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="../sells/sell/sale_register.php">SALE REGISTER</a></li>
												<!--<li><a href="#">SALE SUMMARY</a></li>-->
												<li><a href="../sells/sell/itemwise-sale.php">ITEM WISE SALE</a></li>
												<li><a href="../sells/sell/doctor-wise-sale.php">DOCTOR WISE SALE DETAILS</a></li>
												<li><a href="../sells/sell/doctor-wise-summary.php">DOCTOR WISE SALE SUMMARY</a></li>
												<li><a href="../sells/sell/company_wise_sal.php">COMPANY WISE SALE</a></li>
												<li><a href="../sells/sell/batchwise-sale.php">BATCH WISE SALE</a></li>
												<li><a href="../sells/sell/saleret-reg.php">SALE RETURN REGISTER</a></li>
                                                <li><a href="../sells/sell/item-subcag-sld.php">SUB CATEGORY WISE SALE</a></li>
                                                <!--<li><a href="../sells/sell/productsale.php">QUANTITY WISE ATOM SALE</a></li>-->
                                                <li><a href="../sells/sell/pur_wise_sale.php">PURCHASE WISE SALE</a></li>
                                                <li><a href="../sells/sell/sale_purchase_record.php">DAY WISE SALE-PURCHASE TOTAL</a></li>
                                                <li><a href="../sells/sell/moth_wise_sal.php">MONTH WISE SALE-PURCHASE TOTAL</a></li>
                                               <!-- <li><a href="#">BALANCE AMOUNT CASH BILLS</a></li>-->
											</ul>
										</div>
                                       <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>