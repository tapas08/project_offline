<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-group"></i>&nbsp; ADMIN REPORT</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">MODIFIED PURCHASE INVOICES</a></li>
												<li><a href="#">MODIFIED SALES INVOICES</a></li>
                                                <li><a href="#">BLANK SALE INVOICES</a></li>
                                                <li><a href="#">USERWISE SALE SUMMARY</a></li>
                                                <li><a href="#">SALE MANAGEMENT</a></li>
                                                <li><a href="#">SALE SUMMARY FROM BILL TO BILL NO</a></li>
                                                <li><a href="#">MONTHWISE SALE/PROFIT</a></li>
                                                <li><a href="#">SET SALE BILL ON PURCHASE RATE</a></li>
                                                <li><a href="#">BILL WISE PROFIT</a></li>
                                                <li><a href="#">DOCTOR WISE PROFIT</a></li>
                                                <li><a href="#">MONTH WISE PROFIT</a></li>
                                                <li><a href="#">DISCOUNTED SALE BILLS</a></li>
                                             </ul>
										</div>
                                        <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>