<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-shopping-cart"></i>&nbsp; PURCHASE</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">PURCHASE REGISTER</a></li>
												<li><a href="#">PURCHASE SUMMARY</a></li>
                                                <li><a href="#">PURCHASE SUMMARY-2</a></li>
												<li><a href="#">ITEMWISE PARTYWISE PURCHASE</a></li>
												<li><a href="#">PARTYWISE ITEMWISE PURCHASE</a></li>
												<li><a href="#">COMPANY WISE PURCHASE</a></li>
												<li><a href="#">RATE DIFFERENCE IN PURCHASE</a></li>
												<li><a href="#">PURCHASE RETURN REGISTER</a></li>
                                                <li><a href="#">PURCHASE PROFIT MARGIN</a></li>
                                                <li><a href="#">PURCHASE SCHEEM DIFFERENCE</a></li>
                                                <li><a href="#">SUB CATEGORY WISE PURCHASE</a></li>
                                            </ul>
										</div>
                                        <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>