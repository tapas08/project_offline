<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-info-sign"></i>&nbsp; VAT REPORT</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">VAT PURCHASE DATEWISE</a></li>
												<li><a href="#">VAT PURCHASE PARTYWISE</a></li>
                                                <li><a href="#">VAT PURCHASE SUMMARY</a></li>
                                                <li><a href="#">VAT PURCHASE RETURN</a></li>
                                                <li><a href="#">VAT SALE BILLWISE/SUMMARY</a></li>
                                                <li><a href="#">VAT SALE RETURN</a></li>
                                                <li><a href="#">VAT SALE DATEWISE SUMMARY</a></li>
                                                <li><a href="#">VAT SALE PURCHASE SUMMARY</a></li>
                                                <li><a href="#">VAT ANNEXTURE-J</a></li>
                                                <li><a href="#">VAT ANNEXTURE J1,J2,COMBINE</a></li>
                                                <li><a href="#">VAT STOCK VALUE</a></li>
                                             </ul>
										</div>
                                        <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>