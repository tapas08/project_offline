              <div class="span8">
                    	<form class="form-horizontal" role="form">
  							<div class="form-group">
    							<label class="control-label span2" for="date">FROM DATE :-</label>
    							<div class="span3">
      								<input type="text" class="form-control" placeholder="Enter starting date" style="width:110%; height:25px;">
    							</div>
                                <label class="control-label span2" for="date2"> TO :-</label>
                                <div class="span3">
                                	<input type="text" class="form-control" placeholder="Enter last date" style="width:110%; height:25px;">
                                </div>
  							</div>
                            <div class="clearfix"></div>
                            <div class="form-group">
    							<label class="control-label span2" for="achead">A/C HEAD :-</label>
    							<div class="span10">
      								<input type="text" class="form-control" placeholder="Account Head" style="width:90%; height:25px;">
    							</div>
                            </div>
                             <div class="clearfix"></div>
                             
                            <div class="form-group">
    							<label class="control-label span2" for="manufacture">MANUFACT. :-</label>
    							<div class="span10">
      								<input type="text" class="form-control" placeholder="Manufactured" style="width:90%; height:25px;">
    							</div>
                            </div>
                             <div class="clearfix"></div>
                             
                             <div class="form-group">
    							<label class="control-label span2" for="item">ITEM TYPE :-</label>
    							<div class="span2">
      								<input type="text" class="form-control" placeholder="Item Type" style="width:110%; height:25px;">
    							</div>
                                <label class="control-label span4" for="shelf"> SHELF/RACK :-</label>
                                <div class="span2">
                                	<input type="text" class="form-control" placeholder="Shelf No." style="width:100%; height:25px;">
                                </div>
  							</div>
                            <div class="clearfix"></div>
                            
                           <div class="form-group">
    							<label class="control-label span2" for="product">PRODUCT :-</label>
    							<div class="span5">
      								<input type="text" class="form-control" placeholder="Product Name" style="width:100%; height:25px;">
    							</div>
                                <label class="control-label span2" for="batch" style="padding:0px;">BATCH :</label>
                                <div class="span2">
                                	<input type="text" class="form-control" placeholder="Batch No." style="width:110%; height:25px;">
                                </div>
  							</div>
                            <div class="clearfix"></div>
                            
                            <div class="form-group">
    							<label class="control-label span2" for="sub-category">SUB CAT :-</label>
    							<div class="span3">
      								<select class="form-control" style="width:100%; height:25px;">
                                    	<option>SELECT</option>
                                        <option> </option>
                                        <option> </option>
                                        <option> </option>
                                        <option> </option>
                                    </select>
    							</div>
                                <label class="control-label span2" for="dr-name" style="padding:0px;">DR. NAME :</label>
                                <div class="span4">
                                	<input type="text" class="form-control" placeholder="Enter Doctor name" style="width:110%; height:25px;">
                                </div>
  							</div>
                            <div class="clearfix"></div>
                            
  							<div class="form-group"> 
    							<div class="span-offset-2 span10">
                                	<button type="reset" class="btn btn-default">Cancel</button>
                                    <button type="submit" class="btn btn-default">Show</button>
                                	<button type="submit" class="btn btn-default">Print</button>
      								<button type="submit" class="btn btn-default">Exit</button>
    							</div>
  </div>
</form>

                    
                    </div>