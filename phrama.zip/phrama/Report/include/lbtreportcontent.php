<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-info-sign"></i>&nbsp; LBT REPORT</div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">LBT PURCHASE DATEWISE</a></li>
												<li><a href="#">LBT PURCHASE PARTYWISE</a></li>
                                                <li><a href="#">LBT PURCHASE SUMMARY</a></li>
                                            </ul>
										</div>
                          <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>