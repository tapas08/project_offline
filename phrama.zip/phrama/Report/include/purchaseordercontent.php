<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header"><i class="icon-credit-card"></i>&nbsp; PURCHASE ORDER</a></li></div>
									</div>
                                    <div class="content span12">
    	        						<div class=" span4 pre-scrollable">
											<ul class="nav nav-stacked">
												<li><a href="#">SHORT LISTED ITEMS</a></li>
												<li><a href="#">SHORT LISTED ITEMS(TODAYS)</a></li>
                                                <li><a href="#">NON MOVING ITEMS</a></li>
												<li><a href="#">PENDING P.O. ITEMS</a></li>
												<li><a href="#">SALES WISE SHORT LIST</a></li>
                                             </ul>
										</div>
                                        <?php include('include/form.php'); ?>
								</div>
							</div>
						</div>