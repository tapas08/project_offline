<div id="block_bg" class="block">
                
							<div class="block-content collapse in">
								<div class="span12">
                                	<div class="row">
												<div class="header">Personal History</div>
									</div>
                                        <div class="content col-md-12 pre-scrollable">
											<ul class="nav navbar-nav">
												<li><a href="#">SALE REGISTER</a></li>
												<li><a href="#">SALE SUMMARY</a></li>
												<li><a href="#">ITEM WISE SALE</a></li>
												<li><a href="#">DOCTOR WISE SALE DETAILS</a></li>
												<li><a href="#">DOCTOR WISE SALE SUMMARY</a></li>
												<li><a href="#">COMPANY WISE SALE</a></li>
												<li><a href="#">BATCH WISE SALE</a></li>
												<li><a href="#">SALE RETURN REGISTER</a></li>
                                                <li><a href="#">SUB CATEGORY WISE SALE</a></li>
                                                <li><a href="#">QUANTITY WISE ATOM SALE</a></li>
                                                <li><a href="#">PURCHASE WISE SALE</a></li>
                                                <li><a href="#">DAY WISE SALE-PURCHASE TOTAL</a></li>
                                                <li><a href="#">MONTH WISE SALE-PURCHASE TOTAL</a></li>
                                                <li><a href="#">BALANCE AMOUNT CASH BILLS</a></li>
                                            </ul>
										</div>
								</div>
							</div>
						</div>