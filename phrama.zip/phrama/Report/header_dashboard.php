<!DOCTYPE html>
<html class="no-js">
    <head>
        <title>MATOSHREE MEDICOSE</title>
		<meta name="description" content="">
		<meta name="author" content="Elifree">
		<meta charset="UTF-8">
        <!-- Bootstrap -->
		<link href="admin/images/favicon.ico" rel="icon" type="image">
        <link href="admin/bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <link href="admin/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet" media="screen">
        <link href="admin/bootstrap/css/font-awesome.css" rel="stylesheet" media="screen">
        <link href="admin/bootstrap/css/my_style.css" rel="stylesheet" media="screen">
        <link href="admin/bootstrap/css/print.css" rel="stylesheet" media="print">
        <link href="admin/vendors/easypiechart/jquery.easy-pie-chart.css" rel="stylesheet" media="screen">
        <link href="admin/assets/styles.css" rel="stylesheet" media="screen">
		<!-- calendar css -->
		<link href="admin/vendors/fullcalendar/fullcalendar.css" rel="stylesheet" media="screen">
        <link rel="stylesheet" type="text/css" href="admin/bootstrap/css/basic.css">

		
    </head>
