<div class="navbar navbar-fixed-top navbar-inverse">
        <div class="navbar-inner">
            <div class="container-fluid">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
					<span class="icon-bar"></span>
                </a>
						
               <!-- <a class="brand" href="#">Welcome to Order Management System</a>-->
				
                    
                    <div class="row" style="padding-bottom:2px;">
						<div id="logo">
							<img src="images/logo.png">
						</div>
						<div id="head1">
								
								<div>MATOSHREE MEDICOSE U/O TS LIFECARE</div><br>
						</div>
					</div>
            </div>
        </div>
</div>