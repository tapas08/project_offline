<?php

mysql_select_db('work',mysql_connect('localhost','root',''))or die(mysql_error());

 $GLOBALS['Title'] = "OMS: Order Management System";
?>