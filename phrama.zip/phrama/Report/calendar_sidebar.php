<div class="span3" id="sidebar" style="margin-top:6.2%;">
		<ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
		<li class=""><a href="#"><i class="icon-chevron-right"></i><i class="icon-chevron-left"></i>&nbsp;Back</a></li>	
        <li class=""><a href="masters.php"><i class="icon-chevron-right"></i><i class="icon-suitcase"></i>&nbsp;MASTERS</a></li>
		<li class=""><a href="sale.php"><i class="icon-chevron-right"></i><i class="icon-bar-chart"></i>&nbsp;SALES</a></li>
		<li class=""><a href="purchase.php"><i class="icon-chevron-right"></i><i class="icon-shopping-cart"></i>&nbsp;PURCHASE</a></li>
		<li class=""><a href="expiry.php"><i class="icon-chevron-right"></i><i class="icon-ban-circle"></i>&nbsp;EXPIRY</a></li>
		<li class=""><a href="purchaseorder.php"><i class="icon-chevron-right"></i><i class="icon-credit-card"></i>&nbsp;PURCHASE ORDER</a></li>
		<li class=""><a href="stock.php"><i class="icon-chevron-right"></i><i class="icon-book"></i>&nbsp;STOCK</a></li>
		<li class=""><a href="account.php"><i class="icon-chevron-right"></i><i class="icon-tasks"></i>&nbsp;ACCOUNTS</a></li>
		<li class=""><a href="lbtreport.php"><i class="icon-chevron-right"></i><i class="icon-info-sign"></i>&nbsp;LBT REPORT</a></li>
		<li class=""><a href="vatreport.php"><i class="icon-chevron-right"></i><i class="icon-info-sign"></i>&nbsp;VAT REPORT</a></li>
        <li class=""><a href="adminreport.php"><i class="icon-chevron-right"></i><i class="icon-group"></i>&nbsp;ADMIN REPORT</a></li>
	</ul> 

</div>