<center>
		<footer>
		
		<p>MATOSHREE MEDICOSE Copyright 2016</p>
			
		</footer>
</center>

